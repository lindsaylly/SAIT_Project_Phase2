﻿using System;
using System.Collections.Generic;
//using System.Linq;
using System.Web;

namespace TravEx_WebApp.App_Code
{
    public class Class1
    {
    }
}