﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TravEx_WebApp.App_Code
{
    public class Product
    {
        public Product() { }

        public int ProductId { get; set; }
        public string ProdName { get; set; }

    }
}